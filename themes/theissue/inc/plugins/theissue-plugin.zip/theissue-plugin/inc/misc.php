<?php


/* Author FB, TW & G+ Links */
function theissue_my_new_contactmethods( $contactmethods ) {
	// Add Twitter
	$contactmethods['twitter'] = esc_html__('Twitter URL', 'theissue');
	// Add Facebook
	$contactmethods['facebook'] = esc_html__('Facebook URL', 'theissue');
	// Add Instagram
	$contactmethods['instagram'] = esc_html__('Instagram Profile URL', 'theissue');

	return $contactmethods;
}
add_filter('user_contactmethods','theissue_my_new_contactmethods',10,1);