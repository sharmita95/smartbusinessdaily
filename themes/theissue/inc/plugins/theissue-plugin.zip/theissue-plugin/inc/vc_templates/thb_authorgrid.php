<?php function thb_authorgrid( $atts, $content = null ) {
  $atts = vc_map_get_attributes( 'thb_authorgrid', $atts );
  extract( $atts );


  ob_start();
  if ($author_ids == '' || $author_ids == ' ') {
    $all_authors = get_users(
      array(
        'role__not_in' => array('1','2'),
      )
    );
    $author_list = array_column($all_authors, 'ID');
  } else {
    $author_array = explode(',', $author_ids);
    $author_list = $author_array;
  }

	echo '<div class="row author_list">';
	foreach($author_list as $author) {
		?>
			<div class="small-12 <?php echo esc_attr($columns); ?> columns">
				<div class="author_grid">
          <div class="thb-author-info">
            <?php
              $id = $author;
              $count = count_user_posts($id);
            ?>
            <figure>
              <?php echo get_avatar( $id , '232', '', '', array('class' => 'lazyload')); ?>
            </figure>
            <div class="thb-author-page-description">
              <h4><?php the_author_meta('display_name', $id ); ?></h4>
              <p><?php the_author_meta('description', $id ); ?></p>
            </div>
          </div>
          <div class="thb-author-page-meta">
            <?php if (get_the_author_meta('url', $id ) != '') { ?>
              <a href="<?php echo esc_url(get_the_author_meta('url', $id )); ?>" class="author-link"><i class="thb-icon-link"></i></a>
            <?php } ?>
            <?php if (get_the_author_meta('twitter', $id ) != '') { ?>
              <a href="<?php echo esc_url(get_the_author_meta('twitter', $id )); ?>" class="author-link-twitter"><i class="thb-icon-twitter"></i></a>
            <?php } ?>
            <?php if (get_the_author_meta('facebook', $id ) != '') { ?>
              <a href="<?php echo esc_url(get_the_author_meta('facebook', $id )); ?>" class="author-link-facebook"><i class="thb-icon-facebook"></i></a>
            <?php } ?>
            <?php if (get_the_author_meta('instagram', $id ) != '') { ?>
              <a href="<?php echo esc_url(get_the_author_meta('instagram', $id )); ?>" class="author-link-instagram"><i class="thb-icon-instagram"></i></a>
            <?php } ?>
          </div>
				</div>
			</div>
		<?php
	}
	echo '</div>';

	$out = ob_get_clean();

  return $out;
}
thb_add_short('thb_authorgrid', 'thb_authorgrid');
